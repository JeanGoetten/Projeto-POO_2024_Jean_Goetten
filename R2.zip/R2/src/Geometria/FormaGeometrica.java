package Geometria;

public abstract class FormaGeometrica {

    public abstract double area();
    public abstract double perimetro();
}
