package Eletronicos;

public interface Televisao {
    public static String resolucao = "4k";
    public abstract void mudarDeCanal();
}
