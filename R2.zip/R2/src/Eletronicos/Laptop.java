package Eletronicos;

public interface Laptop {
    public static String tamTela = "1920x1080";

    public abstract void conectarMouse();
}
