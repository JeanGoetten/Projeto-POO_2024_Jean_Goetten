package Eletronicos;

public interface Celular {
    public static String aspectRatio = "16:9";

    public abstract void instalarApp();
}
