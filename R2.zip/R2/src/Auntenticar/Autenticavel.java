package Auntenticar;

public interface Autenticavel {
    public abstract void sessao(boolean value);
}
